#include <string>
#include <iostream>
#include <sstream>
#include <fstream>
#include <cctype>

using namespace std;

int main()
{
    int book_id = 0;
    int chapter_id = 0;
    int verse_id = 0;
    int word_id = 204218;
    string word;
    
    ifstream fileIn;
    fileIn.open("Input3.txt");
    
    ofstream fileOut;
    fileOut.open("Output3.txt");
    
    while (fileIn >> book_id >> chapter_id >> verse_id >> word)
    {
        word_id++;
        fileOut << book_id << " " << chapter_id << " " << verse_id << " " << word_id << " " << word << endl;
    }
    
    return 0;
}