/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bom.vector;

import java.io.*;
import java.util.*;

/**
 *
 * @author Kacey
 */
public class WordCount implements Comparable<WordCount> {
    String word;
    int lemmaFrequency;
    
    public WordCount(String word, int lemmaFrequency) {
        this.word = word;
        this.lemmaFrequency = lemmaFrequency;
    }
    
    @Override
    public int compareTo(WordCount o) {
        String word1 = Integer.toString(lemmaFrequency);
        String word2 = Integer.toString(o.lemmaFrequency);
        return word2.compareTo(word1);
    }
}
