package bom.vector;

import java.util.*;
import java.io.*;
import edu.stanford.nlp.simple.*;

import edu.stanford.nlp.ling.CoreLabel;
import edu.stanford.nlp.ling.HasWord;
import edu.stanford.nlp.process.CoreLabelTokenFactory;
import edu.stanford.nlp.process.DocumentPreprocessor;
import edu.stanford.nlp.process.PTBTokenizer;

/**
 *
 * @author Kacey
 */
public class BOMVector {
    
    /**
     * 
     */
    public static Vector<WordObject> inputFile() {
        Vector<WordObject> words = new Vector<WordObject>();
        
        try {
            System.out.print("Enter the .txt input file name with extension : ");

            Scanner input = new Scanner(System.in);

            File file = new File(input.nextLine());

            input = new Scanner(file);

            while (input.hasNextLine()) {
                String line = input.nextLine();
                String [] tokens = line.split("\\s+");
                int book_id = Integer.parseInt(tokens[0]);
                int chapter_id = Integer.parseInt(tokens[1]);
                int verse_id = Integer.parseInt(tokens[2]);
                int word_id = Integer.parseInt(tokens[3]);
                String word = tokens[4];
                
                Document doc = new Document(word);
                for (Sentence sent : doc.sentences()) {
                    String wordLemma = sent.lemma(0);
                    WordObject wordObject = new WordObject(book_id, chapter_id, verse_id, word_id, wordLemma);
                    words.add(wordObject);
                }
            }
            input.close();
        } catch (Exception ex) {
            ex.printStackTrace();
        }        
        
        return words;
    }
    
    public static void serializeVector(Vector<WordObject> words) {
        try {
            System.out.print("Enter the .ser output file name with extension : ");
            Scanner input = new Scanner(System.in);
            String fileName = input.nextLine();
            OutputStream fileOut = new FileOutputStream(fileName);
            OutputStream buffer = new BufferedOutputStream(fileOut);
            ObjectOutput out = new ObjectOutputStream(buffer);
            
            try {
                out.writeObject(words);
            }
            finally {
            out.close();
            }
            
            buffer.close();
            fileOut.close();
            System.out.printf("Serialized data is saved in " + fileName + '\n');
        }catch(IOException i) {
            i.printStackTrace();
        }
    }
    
    public static Vector<WordObject> deserializeVector() {
        Vector<WordObject> words = null;
        
        try {
            System.out.print("Enter the .ser input file name with extension : ");
            Scanner input = new Scanner(System.in);
            InputStream fileIn = new FileInputStream(input.nextLine());
            InputStream buffer = new BufferedInputStream(fileIn);
            ObjectInput in = new ObjectInputStream(buffer);
            
            try {
                words = (Vector<WordObject>) in.readObject();
            }
            finally {        
                in.close();
            }
            
            buffer.close();
            fileIn.close();
        }catch(IOException i) {
            i.printStackTrace();
        }catch(ClassNotFoundException c) {
            System.out.println("WordObject class not found");
            c.printStackTrace();
        }
        
        return words;
    }
    
    public static Vector<InvertedIndex> createIndex(Vector<WordObject> words) {
        Vector<InvertedIndex> index = new Vector<InvertedIndex>();
        
        for (int i = 0; i < words.size(); i++)
        {
            String word1 = words.get(i).word;
            boolean inIndex = false;
            
            for (int j = 0; j < index.size(); j++)
            {
                String word2 = index.get(j).word;
                if (word1.equals(word2))
                {
                    inIndex = true;
                    index.get(j).word_id_list = index.get(j).word_id_list + " " + Integer.toString(words.get(i).word_id);
                    index.get(j).lemmaFrequency++;
                    Collections.sort(index);
                    break;
                }
            }
            
            if (!inIndex)
            {
                String word_id = Integer.toString(words.get(i).word_id);
                InvertedIndex indexObject = new InvertedIndex(word1,1,word_id);
                index.add(indexObject);
            }
        }
        
        return index;
    }
    
    /**
     * @param args the command line arguments
     * @throws java.io.FileNotFoundException
     */
    public static void main(String[] args) throws FileNotFoundException {
        /*Vector<WordObject> words = new Vector<WordObject>();
        Vector<InvertedIndex> index = new Vector<InvertedIndex>();
        words = inputFile();
        
        index = createIndex(words);
        
        serializeVector(words);
        words = deserializeVector();
        */
        
        ArrayList<String> stopwords = new ArrayList<String>();
        
        try {
            System.out.println("Enter the .txt input file name with extension (document with stopwords):");
            Scanner input = new Scanner(System.in);

            File file = new File(input.nextLine());

            input = new Scanner(file);
            
            while (input.hasNext()) {
                stopwords.add(input.next());
            }
        }
        catch (Exception ex) {
            ex.printStackTrace();
        }
        
        ArrayList<String> lemmas = new ArrayList<String>();
        
        try {
            System.out.print("Enter the .txt input file name with extension (document to be tokenized): ");

            Scanner input = new Scanner(System.in);

            File file = new File(input.nextLine());

            /*
            input = new Scanner(file);
            */
            
            PTBTokenizer<CoreLabel> ptbt = new PTBTokenizer<>(new FileReader(file),
              new CoreLabelTokenFactory(), "");
            while (ptbt.hasNext()) {
                CoreLabel label = ptbt.next();
                
                String word = label.word();
                
                Document doc = new Document(word);
                for (Sentence sent : doc.sentences()) {
                    String wordLemma = sent.lemma(0);
                    boolean isStopword = false;
                    String pattern = "[a-zA-Z]*";
                    
                    for (int i = 0; i < stopwords.size(); i++) {
                        String stopword = stopwords.get(i);
                        if (wordLemma.equals(stopword)) {
                            isStopword = true;
                            break;
                        }                        
                    }                 
                    
                    if (!isStopword && wordLemma.matches(pattern)) {
                        lemmas.add(wordLemma);
                    }
                }
            }
            
            input.close();
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        
        Vector<WordCount> wordcounts = new Vector<WordCount>();
        
        for (int i = 0; i < lemmas.size(); i++)
        {
            String word1 = lemmas.get(i);
            boolean inIndex = false;
            
            for (int j = 0; j < wordcounts.size(); j++)
            {
                String word2 = wordcounts.get(j).word;
                if (word1.equals(word2))
                {
                    inIndex = true;
                    wordcounts.get(j).lemmaFrequency++;
                    Collections.sort(wordcounts);
                    break;
                }
            }
            
            if (!inIndex)
            {
                WordCount wordCountObject = new WordCount(word1,1);
                wordcounts.add(wordCountObject);
            }
        }
        
        try {
            PrintStream fileOut = new PrintStream(new FileOutputStream("BoMWordCounts.txt"));
            for (int i = 0; i < wordcounts.size(); i++) {
                fileOut.println(wordcounts.get(i).word + " " + wordcounts.get(i).lemmaFrequency);           
            }
            fileOut.close();
        }
        catch (Exception ex) {
            ex.printStackTrace();
        }
    }
}
