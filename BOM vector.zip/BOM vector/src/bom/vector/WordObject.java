/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bom.vector;

import java.io.*;
import java.util.*;

/**
 *
 * @author Kacey
 */
public class WordObject implements java.io.Serializable {
    int book_id;
    int chapter_id;
    int verse_id;
    int word_id;
    String word;
    
    public WordObject(int book_id, int chapter_id, int verse_id, int word_id, String word) {
        this.book_id = book_id;
        this.chapter_id = chapter_id;
        this.verse_id = verse_id;
        this.word_id = word_id;
        this.word = word;
    }
    
    void printInfo() {
        System.out.println(book_id + " " + chapter_id + " " + verse_id + " " + word_id + " " + word);
    }
}
