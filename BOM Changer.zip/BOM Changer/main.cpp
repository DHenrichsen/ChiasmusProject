#include <string>
#include <iostream>
#include <sstream>
#include <fstream>
#include <cctype>

using namespace std;

int main()
{
    int book_id = 0;
    int chapter_id = 0;
    int verse_id = 0;
    string verse;
    
    ifstream fileIn;
    fileIn.open("hinckley.txt");
    
    ofstream fileOut;
    fileOut.open("hinckley1.txt");
    
    while (fileIn >> book_id >> chapter_id >> verse_id)
    {
        getline(fileIn, verse);
        
        for (int i = 0, len = verse.size(); i < len; i++)
        {
            if (ispunct(verse[i]))
            {
                if (verse[i+1] == 's')
                {
                    verse.erase(i--, 2);
                }
                else
                {
                    verse.erase(i--, 1);
                }
                len = verse.size();
            }
            
            if (isupper(verse[i]))
            {
                verse[i] = tolower(verse[i]);
            }
        }
        
        istringstream ss(verse);
        string word;
        
        while (ss >> word)
        {
            fileOut << book_id << " " << chapter_id << " " << verse_id << " " << word << endl;
        }
    }
    
    return 0;
}